# lakehouse-contract-enforcer

A PySpark-based **Data Contract enforcement layer** for S3 Lakehouse pipelines. Sits between your Bronze/raw zone and Silver layer, validates incoming data against versioned YAML contracts, detects schema drift, quarantines bad records, and publishes violation reports.

## Why this exists
Most data quality tools (Great Expectations, Deequ) are assertion-based. This project implements the **data contracts** paradigm — contract-first, versioned, producer-accountable — which is the trending approach for 2026 data platforms.

## Features
- YAML-defined contracts with types, nullability, ranges, regex, freshness SLA, PII flags
- PySpark validator: valid rows → Silver, violations → quarantine with per-row reason
- Schema drift detector (new columns, type changes, basic distribution shift)
- DynamoDB-backed contract registry with versioning
- SNS alerts + S3 markdown violation reports
- CLI (`click`) to register / diff / validate contracts

## Architecture
```
s3://raw/orders/*.parquet
        │
        ▼
 [Glue PySpark job] ──► load contract from DynamoDB
        │
        ├──► s3://silver/orders/  (valid rows)
        ├──► s3://quarantine/orders/  (bad rows + reason)
        └──► SNS alert + s3://reports/orders/violations.md
```

## AWS Services
S3 · Glue (PySpark) · Lambda · EventBridge · DynamoDB · SNS · CloudWatch

## Quickstart
```bash
pip install -r requirements.txt
python -m contract_enforcer.cli register examples/contracts/orders_v1.yaml
python -m contract_enforcer.cli validate examples/data/orders_good.parquet --contract orders:v1
python -m contract_enforcer.cli validate examples/data/orders_drift.parquet --contract orders:v1
```

## Project structure
```
contract_enforcer/
  __init__.py
  cli.py              # click CLI
  contract.py         # YAML loader, versioning
  validator.py        # PySpark validation engine
  drift.py            # schema + distribution drift
  registry.py         # DynamoDB contract registry
  reporter.py         # markdown report + SNS alert
glue_jobs/
  enforce_contract.py # Glue job entrypoint
examples/
  contracts/orders_v1.yaml
  data/               # synthetic good/bad/drift datasets
tests/
infra/                # CloudFormation / CDK stubs
```

## Roadmap
- [ ] Iceberg support (currently Parquet)
- [ ] Contract diff visualizer
- [ ] dbt exposures integration

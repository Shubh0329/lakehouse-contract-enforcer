import boto3
from datetime import datetime

def build_markdown_report(dataset: str, total: int, violations: int, drift: dict) -> str:
    lines = [
        f"# Contract Violation Report — {dataset}",
        f"_Generated: {datetime.utcnow().isoformat()}Z_",
        "",
        f"- Total rows: **{total}**",
        f"- Violations: **{violations}** ({violations/total*100:.2f}%)",
        "",
        "## Schema Drift",
        f"- Drift detected: `{drift['drift_detected']}`",
        f"- Added: {drift['added_columns']}",
        f"- Removed: {drift['removed_columns']}",
        f"- Type changes: {drift['type_changes']}",
    ]
    return "\n".join(lines)

def publish_sns(topic_arn: str, subject: str, message: str):
    boto3.client("sns").publish(TopicArn=topic_arn, Subject=subject, Message=message)

from pyspark.sql import DataFrame
from .contract import Contract

def detect_schema_drift(df: DataFrame, contract: Contract) -> dict:
    contract_cols = {c.name: c.type for c in contract.columns}
    df_cols = set(df.columns)

    added = df_cols - contract_cols.keys()
    removed = set(contract_cols.keys()) - df_cols
    type_changes = []
    for name, typ in contract_cols.items():
        if name in df.columns:
            actual = dict(df.dtypes)[name]
            if actual != typ:
                type_changes.append({"column": name, "contract": typ, "actual": actual})

    return {
        "drift_detected": bool(added or removed or type_changes),
        "added_columns": sorted(added),
        "removed_columns": sorted(removed),
        "type_changes": type_changes,
    }

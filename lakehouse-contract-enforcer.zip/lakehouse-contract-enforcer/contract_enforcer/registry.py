import boto3, json
from .contract import Contract

class ContractRegistry:
    def __init__(self, table_name="data_contracts", region="us-east-1"):
        self.table = boto3.resource("dynamodb", region_name=region).Table(table_name)

    def register(self, contract: Contract):
        self.table.put_item(Item={
            "name": contract.name,
            "version": contract.version,
            "owner": contract.owner,
            "fingerprint": contract.fingerprint(),
            "spec": json.dumps(contract.__dict__, default=lambda o: o.__dict__),
        })

    def get(self, name: str, version: str) -> dict:
        return self.table.get_item(Key={"name": name, "version": version}).get("Item")

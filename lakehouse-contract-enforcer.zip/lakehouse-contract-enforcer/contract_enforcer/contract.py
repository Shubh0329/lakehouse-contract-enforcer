from dataclasses import dataclass, field
from typing import List, Optional
import yaml

@dataclass
class ColumnSpec:
    name: str
    type: str
    nullable: bool = False
    min: Optional[float] = None
    max: Optional[float] = None
    regex: Optional[str] = None
    pii: bool = False

@dataclass
class Contract:
    name: str
    version: str
    owner: str
    freshness_sla_hours: int
    columns: List[ColumnSpec] = field(default_factory=list)

    @classmethod
    def from_yaml(cls, path: str) -> "Contract":
        with open(path) as f:
            raw = yaml.safe_load(f)
        cols = [ColumnSpec(**c) for c in raw.pop("columns", [])]
        return cls(columns=cols, **raw)

    def fingerprint(self) -> str:
        import hashlib, json
        payload = json.dumps(
            [(c.name, c.type, c.nullable) for c in self.columns],
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode()).hexdigest()[:12]

from pyspark.sql import DataFrame, SparkSession, functions as F
from .contract import Contract

def validate(df: DataFrame, contract: Contract):
    """Splits df into (valid, quarantine) by contract rules."""
    reasons = F.array()

    for col in contract.columns:
        if col.name not in df.columns:
            df = df.withColumn(col.name, F.lit(None))

        if not col.nullable:
            reasons = F.when(F.col(col.name).isNull(),
                             F.array_union(reasons, F.array(F.lit(f"{col.name}:null")))
                             ).otherwise(reasons)

        if col.min is not None:
            reasons = F.when(F.col(col.name) < col.min,
                             F.array_union(reasons, F.array(F.lit(f"{col.name}:below_min")))
                             ).otherwise(reasons)

        if col.max is not None:
            reasons = F.when(F.col(col.name) > col.max,
                             F.array_union(reasons, F.array(F.lit(f"{col.name}:above_max")))
                             ).otherwise(reasons)

        if col.regex:
            reasons = F.when(~F.col(col.name).rlike(col.regex),
                             F.array_union(reasons, F.array(F.lit(f"{col.name}:regex")))
                             ).otherwise(reasons)

    enriched = df.withColumn("_violations", reasons)
    valid = enriched.filter(F.size("_violations") == 0).drop("_violations")
    quarantine = enriched.filter(F.size("_violations") > 0)
    return valid, quarantine

import click
from .contract import Contract
from .registry import ContractRegistry

@click.group()
def cli(): pass

@cli.command()
@click.argument("yaml_path")
def register(yaml_path):
    c = Contract.from_yaml(yaml_path)
    ContractRegistry().register(c)
    click.echo(f"Registered {c.name}:{c.version} fingerprint={c.fingerprint()}")

@cli.command()
@click.argument("data_path")
@click.option("--contract", required=True, help="name:version")
def validate(data_path, contract):
    from pyspark.sql import SparkSession
    from .validator import validate as run_validate
    from .drift import detect_schema_drift

    name, version = contract.split(":")
    spark = SparkSession.builder.appName("contract-validate").getOrCreate()
    df = spark.read.parquet(data_path)
    # In real usage, load Contract from registry
    c = Contract.from_yaml(f"examples/contracts/{name}_{version}.yaml")
    drift = detect_schema_drift(df, c)
    valid, bad = run_validate(df, c)
    click.echo(f"Valid: {valid.count()}  Quarantine: {bad.count()}  Drift: {drift['drift_detected']}")

if __name__ == "__main__":
    cli()
